
local LTable = torch.class('LinkedTable')

function LTable:__init()
  self.table = {}
  self.keys = {}
end

function LTable:put(key, value)
end


